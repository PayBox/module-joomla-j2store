<?php
/*
 * --------------------------------------------------------------------------------
   Quantum Technologies Kazakhstan  - J2Store - Payment Plugin - PayBox
 * --------------------------------------------------------------------------------
 * @package		Joomla! 3.5x
 * @subpackage	J2 Store
 * @author    	Galym Sarsebek - Weblogicx India https://www.paybox.money
 * @copyright	Copyright (c) 2020 Quantum Technologies Kazakhstan Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		https://paybox.money
 * --------------------------------------------------------------------------------
*/

defined('_JEXEC') or die('Restricted access'); ?>

<?php echo $vars->message; ?>
